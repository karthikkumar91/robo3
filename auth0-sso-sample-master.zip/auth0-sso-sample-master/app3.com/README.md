# app3.com

This is the app3.com for the SSO example. Remember to start all 3 apps to try everything out and to [configure `/etc/hosts` correctly](https://github.com/auth0/auth0-sso-sample#running)

#Running the example

In order to run the example you need to have npm and nodejs installed.

Just run `node server.js` and try calling [http://app3.com:3002/](http://app3.com:3002/)
