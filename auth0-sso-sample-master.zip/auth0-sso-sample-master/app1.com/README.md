# app1.com

This is the starting point for the SSO example. Remember to start all 3 apps to try everything out and to [configure `/etc/hosts` correctly](https://github.com/auth0/auth0-sso-sample#running)

## Running the example

In order to run the example you need to just start a server. What we suggest is doing the following:

1. Install node
2. run `npm install -g serve`
3. run `serve -l 3000` in the directory of this project.

Go to `http://app1.com:3000` and you'll see the app running :).
