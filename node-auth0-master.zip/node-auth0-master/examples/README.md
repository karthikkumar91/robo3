# Deprecation Notice

These samples have been deprecated. Please see the [**auth0-samples**](https://github.com/auth0-samples) org for the latest Auth0 and Node.js integration samples.