module.exports = {
  extractParts: require('./extractParts'),
  ensureProperty: require('./ensureProperty'),
  ensureMethod: require('./ensureMethod')
};
