var constants = (module.exports = {});

constants.BASE_API_URL = 'https://login.auth0.com/api/v2/';
constants.EU_BASE_API_URL = 'https://login.eu.auth0.com/api/v2/';
constants.USERS_ENDPOINT = '/users/%s';
